<script>
</script>

<template>
  <h1>Vue Starter Page</h1>

  <div class="main-info">
    <p>
      This is a sample starter Vue component. This component will be deleted during your exercise.
    </p>
  </div>
</template>

<style scoped>
</style>