<script>
</script>

<template>
  <div class="copyright-info">
    <p>
        &copy; Copyright 2025
    </p>
  </div>
</template>

<style scoped>
</style>