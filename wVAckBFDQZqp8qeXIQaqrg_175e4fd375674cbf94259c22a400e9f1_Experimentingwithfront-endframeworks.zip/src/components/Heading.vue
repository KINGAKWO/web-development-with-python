<script>
</script>

<template>
  <h2>Welcome to Vue!</h2>

  <div class="navigation">
    | <a href="index.html">Link to Home</a> | <a href="https://www.coursera.org">Coursera</a> | 
    <hr>
    <p>
      Welcome to our home page.
    </p>
  </div>
</template>

<style scoped>
a{
  color: green;
  font-weight: bolder;
}
</style>